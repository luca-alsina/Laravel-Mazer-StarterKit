<footer>
    <div class="footer clearfix mb-0 text-muted">
        <div class="float-start">
            <p>{{ __('admin.footer.copyrigth') }}</p>
        </div>
        <div class="float-end">
            <p>{{ __('admin.footer.credits') }}</p>
        </div>
    </div>
</footer>
