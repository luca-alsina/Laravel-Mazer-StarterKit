<script src="{{ asset('admin/js/bootstrap.js') }}"></script>
<script src="{{ asset('admin/js/app.js') }}"></script>

<!-- Need: Apexcharts -->
<script src="{{ asset('admin/extensions/apexcharts/apexcharts.min.js') }}"></script>
<script src="{{ asset('admin/js/pages/dashboard.js') }}"></script>
